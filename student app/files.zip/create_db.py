import sqlite3
import hashlib
import os

# ============================================================
#  UTILITY
# ============================================================

def hash_password(plain: str) -> str:
    """SHA-256 + salt — كلمة المرور لا تُحفظ أبداً كـ plain text"""
    salt = "school_app_salt_2024"          # في production استخدم os.urandom()
    return hashlib.sha256((salt + plain).encode()).hexdigest()


# ============================================================
#  CREATE DATABASE
# ============================================================

def create_db():
    con = sqlite3.connect('school.db')
    cur = con.cursor()

    # تفعيل Foreign Keys في SQLite (مش شغّال by default)
    cur.execute("PRAGMA foreign_keys = ON")

    # ----------------------------------------------------------------
    # 1. Account — مستخدمون عاديون (sign-up)
    # ----------------------------------------------------------------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS Account(
            ID          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT    NOT NULL,
            username    TEXT    NOT NULL UNIQUE,
            password    TEXT    NOT NULL         -- مشفّرة SHA-256
        )
    """)

    # ----------------------------------------------------------------
    # 2. Admin — المسؤولون
    # ----------------------------------------------------------------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS Admin(
            admin_ID        INTEGER PRIMARY KEY AUTOINCREMENT,
            admin_name      TEXT    NOT NULL,
            admin_username  TEXT    NOT NULL UNIQUE,
            admin_password  TEXT    NOT NULL     -- مشفّرة SHA-256
        )
    """)

    # ----------------------------------------------------------------
    # 3. first_student — طلاب الصف الأول الإعدادي
    #    grade يمكن تمديده لـ 2 و 3 لاحقاً
    # ----------------------------------------------------------------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS first_student(
            s_ID            INTEGER PRIMARY KEY AUTOINCREMENT,
            student_name    TEXT    NOT NULL,
            student_gender  TEXT    CHECK(student_gender IN ('Male','Female')),
            student_age     INTEGER,
            address         TEXT,
            contact         TEXT,
            enrollment_date TEXT,
            last_school     TEXT,
            repeated_years  INTEGER DEFAULT 0,
            health_problem  TEXT    DEFAULT 'None',
            final_result    TEXT    DEFAULT 'Pending',
            is_active       INTEGER DEFAULT 1    -- 1=نشط  0=مُرحَّل/منقطع
        )
    """)

    # ----------------------------------------------------------------
    # 4. islamic_marks — مربوطة بـ student_id (مش بالاسم!)
    # ----------------------------------------------------------------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS islamic_marks(
            i_ID            INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id      INTEGER NOT NULL
                            REFERENCES first_student(s_ID)
                            ON DELETE CASCADE ON UPDATE CASCADE,
            student_name    TEXT,               -- للعرض السريع فقط
            st_month        REAL DEFAULT 0,
            nd_month        REAL DEFAULT 0,
            chapter1        REAL DEFAULT 0,
            half_year       REAL DEFAULT 0,
            st_month1       REAL DEFAULT 0,
            nd_month2       REAL DEFAULT 0,
            chapter2        REAL DEFAULT 0,
            chapter3        REAL DEFAULT 0,
            final_exam      REAL DEFAULT 0,
            final_result    TEXT DEFAULT 'Pending',
            academic_year   TEXT DEFAULT '2024-2025'
        )
    """)

    # ----------------------------------------------------------------
    # 5. arabic_marks — نفس الهيكل مع foreign key
    # ----------------------------------------------------------------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS arabic_marks(
            a_ID            INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id      INTEGER NOT NULL
                            REFERENCES first_student(s_ID)
                            ON DELETE CASCADE ON UPDATE CASCADE,
            student_name    TEXT,
            st_month        REAL DEFAULT 0,
            nd_month        REAL DEFAULT 0,
            chapter1        REAL DEFAULT 0,
            half_year       REAL DEFAULT 0,
            st_month1       REAL DEFAULT 0,
            nd_month2       REAL DEFAULT 0,
            chapter2        REAL DEFAULT 0,
            chapter3        REAL DEFAULT 0,
            final_exam      REAL DEFAULT 0,
            final_result    TEXT DEFAULT 'Pending',
            academic_year   TEXT DEFAULT '2024-2025'
        )
    """)

    # ----------------------------------------------------------------
    # 6. teachers — مع national_id فريد
    # ----------------------------------------------------------------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS teachers(
            t_id            INTEGER PRIMARY KEY AUTOINCREMENT,
            name            TEXT    NOT NULL,
            subject         TEXT    NOT NULL,
            phone           TEXT,
            national_id     TEXT    UNIQUE,      -- رقم قومي لا يتكرر
            salary          REAL    DEFAULT 0,
            college_degree  TEXT,
            hire_date       TEXT,
            is_active       INTEGER DEFAULT 1
        )
    """)

    # ----------------------------------------------------------------
    # 7. attendance — جدول الحضور والغياب (جديد)
    # ----------------------------------------------------------------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS attendance(
            att_id          INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id      INTEGER NOT NULL
                            REFERENCES first_student(s_ID)
                            ON DELETE CASCADE,
            att_date        TEXT    NOT NULL,    -- YYYY-MM-DD
            status          TEXT    NOT NULL
                            CHECK(status IN ('Present','Absent','Excused')),
            notes           TEXT,
            UNIQUE(student_id, att_date)         -- طالب مرة واحدة في اليوم
        )
    """)

    # ----------------------------------------------------------------
    # 8. activity_log — سجل كل عملية (Audit Log) (جديد)
    # ----------------------------------------------------------------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS activity_log(
            log_id          INTEGER PRIMARY KEY AUTOINCREMENT,
            admin_username  TEXT    NOT NULL,
            action          TEXT    NOT NULL,    -- مثلاً: ADD_TEACHER, DELETE_STUDENT
            target_table    TEXT,
            target_id       INTEGER,
            details         TEXT,                -- تفاصيل إضافية JSON أو نص
            log_time        TEXT    DEFAULT (datetime('now','localtime'))
        )
    """)

    con.commit()
    con.close()
    print("✅  قاعدة البيانات اتعملت بنجاح مع كل التطويرات.")


# ============================================================
#  MIGRATE — لو عندك DB قديمة وعايز تحدّثها بدون حذف البيانات
# ============================================================

def migrate_existing_db():
    """
    تضيف الأعمدة والجداول الجديدة على DB موجودة.
    آمنة تماماً — مش بتحذف أي بيانات.
    """
    con = sqlite3.connect('school.db')
    cur = con.cursor()
    cur.execute("PRAGMA foreign_keys = ON")

    def add_column_if_missing(table, column, definition):
        cur.execute(f"PRAGMA table_info({table})")
        cols = [row[1] for row in cur.fetchall()]
        if column not in cols:
            cur.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")
            print(f"  ✚ أُضيف عمود  {column}  لـ  {table}")

    def create_table_if_missing(sql, name):
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (name,))
        if not cur.fetchone():
            cur.execute(sql)
            print(f"  ✚ أُنشئ جدول  {name}")

    print("🔄  جارٍ تحديث قاعدة البيانات...")

    # --- first_student: أعمدة جديدة ---
    add_column_if_missing('first_student', 'is_active',      'INTEGER DEFAULT 1')
    add_column_if_missing('first_student', 'repeated_years', 'INTEGER DEFAULT 0')

    # --- islamic_marks: عمود student_id ---
    add_column_if_missing('islamic_marks', 'student_id',    'INTEGER')
    add_column_if_missing('islamic_marks', 'academic_year', "TEXT DEFAULT '2024-2025'")

    # --- arabic_marks: عمود student_id ---
    add_column_if_missing('arabic_marks', 'student_id',    'INTEGER')
    add_column_if_missing('arabic_marks', 'academic_year', "TEXT DEFAULT '2024-2025'")

    # --- teachers: أعمدة جديدة ---
    add_column_if_missing('teachers', 'hire_date',  'TEXT')
    add_column_if_missing('teachers', 'is_active',  'INTEGER DEFAULT 1')

    # --- جداول جديدة ---
    create_table_if_missing("""
        CREATE TABLE attendance(
            att_id     INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL REFERENCES first_student(s_ID) ON DELETE CASCADE,
            att_date   TEXT    NOT NULL,
            status     TEXT    NOT NULL CHECK(status IN ('Present','Absent','Excused')),
            notes      TEXT,
            UNIQUE(student_id, att_date)
        )""", 'attendance')

    create_table_if_missing("""
        CREATE TABLE activity_log(
            log_id         INTEGER PRIMARY KEY AUTOINCREMENT,
            admin_username TEXT NOT NULL,
            action         TEXT NOT NULL,
            target_table   TEXT,
            target_id      INTEGER,
            details        TEXT,
            log_time       TEXT DEFAULT (datetime('now','localtime'))
        )""", 'activity_log')

    # --- تشفير كلمات المرور القديمة ---
    _rehash_passwords(cur)

    con.commit()
    con.close()
    print("✅  التحديث اكتمل بنجاح.")


def _rehash_passwords(cur):
    """تشفير الباسوردات الموجودة اللي طولها مش 64 (يعني لسه plain text)"""
    salt = "school_app_salt_2024"

    # Admin
    cur.execute("SELECT admin_ID, admin_password FROM Admin")
    for row in cur.fetchall():
        if len(row[1]) != 64:           # SHA-256 hex = 64 حرف دايماً
            hashed = hashlib.sha256((salt + row[1]).encode()).hexdigest()
            cur.execute("UPDATE Admin SET admin_password=? WHERE admin_ID=?", (hashed, row[0]))
            print(f"  🔒 تم تشفير باسورد Admin ID={row[0]}")

    # Account
    cur.execute("SELECT ID, password FROM Account")
    for row in cur.fetchall():
        if len(row[1]) != 64:
            hashed = hashlib.sha256((salt + row[1]).encode()).hexdigest()
            cur.execute("UPDATE Account SET password=? WHERE ID=?", (hashed, row[0]))
            print(f"  🔒 تم تشفير باسورد Account ID={row[0]}")


# ============================================================
#  AUDIT LOG HELPER — استخدمها في كل صفحة
# ============================================================

def log_action(admin_username: str, action: str,
               target_table: str = None, target_id: int = None,
               details: str = None):
    """
    استخدامها في أي صفحة:
        from create_db import log_action
        log_action('admin', 'DELETE_TEACHER', 'teachers', teacher_id, f'Name: {name}')
    """
    try:
        con = sqlite3.connect('school.db')
        cur = con.cursor()
        cur.execute("""
            INSERT INTO activity_log(admin_username, action, target_table, target_id, details)
            VALUES (?, ?, ?, ?, ?)
        """, (admin_username, action, target_table, target_id, details))
        con.commit()
        con.close()
    except Exception:
        pass    # السجل لا يوقف أي عملية أساسية


# ============================================================
#  ENTRY POINT
# ============================================================

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == '--migrate':
        migrate_existing_db()
    else:
        create_db()
