from customtkinter import *
from tkinter import *
from PIL import Image
from tkinter import messagebox
import sqlite3
import hashlib

import dashboard

# ============================================================
#  نفس دالة التشفير الموجودة في create_db.py
# ============================================================

def hash_password(plain: str) -> str:
    salt = "school_app_salt_2024"
    return hashlib.sha256((salt + plain).encode()).hexdigest()


class LoginClass:
    def __init__(self, root):
        self.root = root
        self.root.geometry('1100x600+100+50')
        self.root.title('Login Page')
        self.root.config(bg='#F6F5F5')
        self.root.resizable(False, False)

        # ------------------------------------------------ open dashboard
        def open_dashboard():
            window = Toplevel()
            dashboard.DashboardClass(window)
            root.withdraw()
            window.deiconify()

        # ------------------------------------------------ login (مع تشفير)
        def login():
            username = var_username.get().strip()
            password = var_password.get()

            if not username or not password:
                messagebox.showerror("خطأ", "من فضلك أدخل اسم المستخدم وكلمة المرور.")
                return

            hashed = hash_password(password)

            try:
                con = sqlite3.connect('school.db')
                cur = con.cursor()
                cur.execute(
                    "SELECT * FROM Admin WHERE admin_username=? AND admin_password=?",
                    (username, hashed)
                )
                result = cur.fetchone()
                con.close()

                if result:
                    # سجّل الدخول في الـ audit log
                    _log_login(username, success=True)
                    messagebox.showinfo("تم", "تم تسجيل الدخول بنجاح.\n\nاضغط OK للمتابعة.")
                    open_dashboard()
                else:
                    _log_login(username, success=False)
                    messagebox.showerror("خطأ", "اسم المستخدم أو كلمة المرور غلط.\n"
                                                "يجب أن تكون حساب admin للدخول.")
            except Exception as e:
                messagebox.showerror("خطأ", f"حدث خطأ: {str(e)}")

        def _log_login(username, success):
            """تسجيل محاولات الدخول في activity_log"""
            try:
                con = sqlite3.connect('school.db')
                cur = con.cursor()
                action = "LOGIN_SUCCESS" if success else "LOGIN_FAILED"
                cur.execute(
                    "INSERT INTO activity_log(admin_username, action, details) VALUES (?,?,?)",
                    (username, action, f"IP: local")
                )
                con.commit()
                con.close()
            except Exception:
                pass    # الـ log لا يوقف عملية الدخول

        # ===================== switch frame =====================
        login_frame   = CTkFrame(root, width=1080, height=550, fg_color='#F6F5F5', bg_color='#F6F5F5')
        sign_up_frame = CTkFrame(root, width=1080, height=550, fg_color='#F6F5F5', bg_color='#F6F5F5')

        for frame in (login_frame, sign_up_frame):
            frame.place(x=10, y=20)

        def show_frame(frame):
            frame.tkraise()

        show_frame(login_frame)

        # ===================== login frame =====================
        img = CTkImage(Image.open('images/login.png'), size=(490, 400))
        img_lbl = CTkLabel(login_frame, text='', image=img, fg_color='#F6F5F5')
        img_lbl.place(x=10, y=70)

        var_username = StringVar()
        var_password = StringVar()

        frame = CTkFrame(login_frame, width=520, height=500,
                         fg_color='#F6F5F5', bg_color='#F6F5F5',
                         border_width=2, corner_radius=30, border_color='#DA7297')
        frame.place(x=520, y=20)

        CTkLabel(frame, text='Login Page', corner_radius=10, fg_color='#DA7297',
                 width=200, height=30, text_color='white',
                 font=('arial', 20, 'bold')).place(x=160, y=50)

        CTkLabel(frame, text='Login To Continue', width=200, height=25,
                 text_color='#DA7297', font=('arial', 18, 'bold')).place(x=30, y=110)

        CTkLabel(frame, text='Not A Member?', width=150, height=25,
                 text_color='#DA7297', font=('arial', 14, 'bold')).place(x=30, y=150)

        CTkLabel(frame, text='Enter Your Username.', width=200, height=25,
                 text_color='gray', font=('arial', 14)).place(x=25, y=200)
        CTkEntry(frame, textvariable=var_username, width=350, height=35,
                 font=('courier', 14), border_width=1, border_color='#DA7297',
                 justify='center').place(x=50, y=230)

        CTkLabel(frame, text='Enter Your Password.', width=200, height=25,
                 text_color='gray', font=('arial', 14)).place(x=25, y=280)
        CTkEntry(frame, textvariable=var_password, width=350, height=35,
                 font=('courier', 14), border_width=1, border_color='#DA7297',
                 justify='center', show='*').place(x=50, y=310)   # ← show='*' للباسورد

        CTkButton(frame, text='Forgot Password', width=150, height=20,
                  fg_color='transparent', text_color='#DA7297',
                  font=('arial', 16, 'bold'), bg_color='transparent',
                  hover_color='#F6F5F5',
                  command=lambda: forgot_password()).place(x=150, y=360)

        CTkButton(frame, text='Sign Up Page', width=100, height=20,
                  fg_color='transparent', text_color='gray',
                  font=('arial', 14, 'bold'), bg_color='transparent',
                  hover_color='#F6F5F5',
                  command=lambda: show_frame(sign_up_frame)).place(x=160, y=150)

        CTkButton(frame, text='Login', width=150, height=20, border_spacing=20,
                  fg_color='#DA7297', text_color='white', bg_color='#F6F5F5',
                  font=('arial', 16, 'bold'), border_color='#DA7297',
                  hover_color='#DA7297', border_width=2, corner_radius=20,
                  command=login).place(x=155, y=400)

        # ===================== forgot password =====================
        def forgot_password():
            win = Toplevel()
            win.geometry('400x430+680+150')
            win.title('Forgot Password')
            win.config(bg='#F6F5F5')
            win.resizable(False, False)

            CTkLabel(win, text='Update Your Password', width=200, height=25,
                     text_color='#DA7297', font=('arial', 16, 'bold')).place(x=50, y=70)

            CTkLabel(win, text='Enter the username', height=25,
                     text_color='gray', font=('arial', 14)).place(x=55, y=110)
            username_en = CTkEntry(win, width=300, height=35, font=('arial', 14),
                                   border_width=1, border_color='#DA7297')
            username_en.place(x=50, y=140)

            CTkLabel(win, text='Enter the New Password', height=25,
                     text_color='gray', font=('arial', 14)).place(x=55, y=180)
            pass_en = CTkEntry(win, width=300, height=35, font=('arial', 14),
                               border_width=1, border_color='#DA7297', show='*')
            pass_en.place(x=50, y=210)

            def update_pass():
                u = username_en.get().strip()
                p = pass_en.get()
                if not u or not p:
                    messagebox.showerror("خطأ", "أدخل الـ username والباسورد الجديد.")
                    return
                if len(p) < 6:
                    messagebox.showerror("خطأ", "كلمة المرور أقل من 6 أحرف.")
                    return
                hashed = hash_password(p)
                try:
                    con = sqlite3.connect('school.db')
                    cur = con.cursor()
                    cur.execute("UPDATE Admin SET admin_password=? WHERE admin_username=?",
                                (hashed, u))
                    if cur.rowcount == 0:
                        messagebox.showerror("خطأ", "الـ username مش موجود.")
                    else:
                        con.commit()
                        messagebox.showinfo("تم", "تم تحديث كلمة المرور.")
                        win.destroy()
                    con.close()
                except Exception as e:
                    messagebox.showerror("خطأ", str(e))

            CTkButton(win, text='Update Password', width=180, height=10, border_spacing=15,
                      fg_color='#DA7297', text_color='white', bg_color='#F6F5F5',
                      font=('arial', 14, 'bold'), border_color='#DA7297',
                      hover_color='#DA7297', border_width=2, corner_radius=20,
                      command=update_pass).place(x=110, y=270)

        # ===================== sign up frame =====================
        name             = StringVar()
        username_var     = StringVar()
        password_var     = StringVar()
        confirm_password = StringVar()

        img2 = CTkImage(Image.open('images/login.png'), size=(490, 400))
        CTkLabel(sign_up_frame, text='', image=img2, fg_color='#F6F5F5').place(x=10, y=70)

        signup_frame = CTkFrame(sign_up_frame, width=520, height=500,
                                fg_color='#F6F5F5', bg_color='#F6F5F5',
                                border_width=2, corner_radius=30, border_color='#DA7297')
        signup_frame.place(x=520, y=20)

        CTkLabel(signup_frame, text='Sign Up Page', corner_radius=10, fg_color='#DA7297',
                 width=200, height=25, text_color='white',
                 font=('arial', 20, 'bold')).place(x=150, y=20)

        CTkLabel(signup_frame, text='Create Account', width=200, height=25,
                 text_color='#DA7297', font=('arial', 16, 'bold')).place(x=20, y=65)

        CTkLabel(signup_frame, text='Already a Member?', width=150, height=25,
                 text_color='#DA7297', font=('arial', 14, 'bold')).place(x=70, y=90)

        CTkButton(signup_frame, text='Login Page', width=100, height=20,
                  fg_color='transparent', text_color='gray',
                  font=('arial', 14, 'bold'), bg_color='transparent',
                  hover_color='#F6F5F5',
                  command=lambda: show_frame(login_frame)).place(x=210, y=90)

        for lbl_text, var, y_lbl, y_en, is_pass in [
            ('Enter Your Name.',             name,             120, 150, False),
            ('Enter Your Username.',         username_var,     190, 220, False),
            ('Enter Your Password.',         password_var,     260, 290, True),
            ('Confirm Password.',            confirm_password, 330, 360, True),
        ]:
            CTkLabel(signup_frame, text=lbl_text, height=25,
                     text_color='gray', font=('arial', 14)).place(x=75, y=y_lbl)
            kw = dict(textvariable=var, width=350, height=35, font=('courier', 14),
                      border_width=1, border_color='#DA7297', justify='center')
            if is_pass:
                kw['show'] = '*'
            CTkEntry(signup_frame, **kw).place(x=75, y=y_en)

        def clear_signup():
            for v in (name, username_var, password_var, confirm_password):
                v.set("")

        def sign_up():
            n, u, p, cp = (name.get().strip(), username_var.get().strip(),
                           password_var.get(), confirm_password.get())
            if not all([n, u, p, cp]):
                messagebox.showerror('خطأ', 'من فضلك أدخل كل البيانات.')
                return
            if p != cp:
                messagebox.showerror('خطأ', 'كلمة المرور والتأكيد مش متطابقين.')
                return
            if len(p) < 6:
                messagebox.showerror('خطأ', 'كلمة المرور أقل من 6 أحرف.')
                return

            hashed = hash_password(p)           # ← التشفير قبل الحفظ
            try:
                con = sqlite3.connect('school.db')
                cur = con.cursor()
                cur.execute("INSERT INTO Account(name, username, password) VALUES(?,?,?)",
                            (n, u, hashed))
                con.commit()
                con.close()
                messagebox.showinfo('تم', 'تم إنشاء الحساب بنجاح.')
                clear_signup()
            except sqlite3.IntegrityError:
                messagebox.showerror('خطأ', 'اسم المستخدم موجود بالفعل، اختار غيره.')
            except Exception as e:
                messagebox.showerror('خطأ', f'حدث خطأ: {str(e)}')

        CTkButton(signup_frame, text='Sign Up', width=150, height=20, border_spacing=20,
                  fg_color='#DA7297', text_color='white', bg_color='#F6F5F5',
                  font=('arial', 16, 'bold'), border_color='#DA7297',
                  hover_color='#DA7297', border_width=2, corner_radius=20,
                  command=sign_up).place(x=155, y=410)


if __name__ == "__main__":
    root = Tk()
    LoginClass(root)
    root.mainloop()
