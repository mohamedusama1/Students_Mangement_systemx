from customtkinter import *
from tkinter import *
from PIL import Image
from time import strftime
from tkinter import ttk, messagebox
import sqlite3
import hashlib

import dashboard
from create_db import hash_password, log_action


class AdminClass:
    def __init__(self, root, current_admin="admin"):
        self.root = root
        self.root.geometry('1200x690+100+5')
        self.root.title('Admin Page')
        self.root.config(bg='white')
        self.root.resizable(False, False)
        self.current_admin = current_admin   # اسم الأدمن المسجّل دخوله

        def date():
            date_1 = strftime('%I:%M:%S %p \t %A \t %b/%d/%Y')
            date_lbl.config(text=date_1)
            date_lbl.after(1000, date)

        # ============================== head frame ==========================
        up_frame = CTkFrame(root, width=1199, height=70, bg_color='#F6F5F5',
                            fg_color='#F6F5F5', border_color='#DA7297', border_width=2)
        up_frame.place(x=1, y=1)

        text_lbl = Label(up_frame, text='Admin Page', font=('courier', 18, 'bold'),
                         bg='#F6F5F5', fg='#DA7297')
        text_lbl.place(x=150, y=5, width=200, height=60)

        date_lbl = Label(up_frame, font=('courier', 18, 'bold'), bg='#F6F5F5', fg='#DA7297')
        date_lbl.place(x=590, y=5, width=570, height=60)
        date()

        def back():
            win = Toplevel()
            dashboard.DashboardClass(win)
            root.withdraw()
            win.deiconify()

        CTkButton(up_frame, text='←', width=100, height=68,
                  fg_color='#DA7297', text_color='white', bg_color='#F6F5F5',
                  font=('arial', 30, 'bold'), hover_color='#DA7297',
                  border_color='#DA7297', corner_radius=0,
                  command=back).place(x=2, y=2)

        # ============================== main frame ==========================
        head_frame = CTkFrame(root, width=1197, height=615, bg_color='white',
                              fg_color='#F6F5F5', border_color='#DA7297', border_width=2)
        head_frame.place(x=1, y=72)

        Label(head_frame, text='WELCOME ADMIN\nPAGE', font=('courier', 25, 'bold'),
              bg='#F6F5F5', fg='#DA7297').place(x=20, y=50, width=300, height=100)

        logo_img = CTkImage(Image.open('images/admin.png'), size=(250, 250))
        CTkLabel(head_frame, text='', image=logo_img,
                 fg_color='#F6F5F5').place(x=350, y=20)

        # ================================================================
        #  ACCOUNT SECTION (الأعمدة اليسار)
        # ================================================================
        acc_id       = StringVar()
        acc_name     = StringVar()
        acc_username = StringVar()
        # الباسورد لا يُعرض أبداً — فقط للكتابة عند التعديل

        def get_connection():
            con = sqlite3.connect('school.db')
            con.execute("PRAGMA foreign_keys = ON")
            return con

        # -------- Account CRUD --------
        def show_accounts():
            con = get_connection()
            cur = con.cursor()
            try:
                cur.execute("SELECT ID, name, username FROM Account")
                rows = cur.fetchall()
                new_account_tree.delete(*new_account_tree.get_children())
                for i, row in enumerate(rows):
                    tag = 'evenrow' if i % 2 == 0 else 'oddrow'
                    # عرض '••••••••' بدل الباسورد الحقيقية
                    new_account_tree.insert('', END,
                        values=(row[0], row[1], row[2], '••••••••'), tags=(tag,))
            except Exception as ex:
                messagebox.showerror('خطأ', str(ex))
            finally:
                con.close()

        def get_account_data(ev):
            item = new_account_tree.focus()
            row  = new_account_tree.item(item)['values']
            if row:
                acc_id.set(row[0])
                acc_name.set(row[1])
                acc_username.set(row[2])
                # لا نملأ حقل الباسورد من الـ DB (مشفّرة ومش قابلة للقراءة)

        def clear_account():
            for v in (acc_id, acc_name, acc_username):
                v.set("")
            en_acc_pass.delete(0, END)

        def delete_account():
            if not acc_id.get():
                messagebox.showerror("خطأ", "اختار حساب من الجدول أولاً.")
                return
            if not messagebox.askyesno("تأكيد", f"هتحذف الحساب: {acc_username.get()}\nمتأكد؟"):
                return
            try:
                con = get_connection()
                cur = con.cursor()
                cur.execute("DELETE FROM Account WHERE ID=?", (acc_id.get(),))
                con.commit()
                con.close()
                log_action(self.current_admin, "DELETE_ACCOUNT", "Account",
                           int(acc_id.get()), f"Username: {acc_username.get()}")
                show_accounts()
                clear_account()
                messagebox.showinfo("تم", "تم حذف الحساب.")
            except Exception as ex:
                messagebox.showerror("خطأ", str(ex))

        def upgrade_to_admin():
            """ترقية حساب عادي إلى Admin"""
            if not acc_id.get():
                messagebox.showerror("خطأ", "اختار حساب من الجدول أولاً.")
                return
            if not messagebox.askyesno("تأكيد",
                    f"هترقّي الحساب: {acc_username.get()} إلى Admin\nمتأكد؟"):
                return
            try:
                con = get_connection()
                cur = con.cursor()
                cur.execute("SELECT * FROM Account WHERE ID=?", (acc_id.get(),))
                data = cur.fetchone()
                if not data:
                    messagebox.showerror("خطأ", "الحساب مش موجود.")
                    con.close()
                    return

                # التحقق إن الـ username مش موجود بالفعل في Admin
                cur.execute("SELECT admin_ID FROM Admin WHERE admin_username=?", (data[2],))
                if cur.fetchone():
                    messagebox.showerror("خطأ", "هذا الـ username موجود بالفعل في الأدمن.")
                    con.close()
                    return

                cur.execute(
                    "INSERT INTO Admin(admin_name, admin_username, admin_password) VALUES(?,?,?)",
                    (data[1], data[2], data[3])   # الباسورد بالفعل مشفّرة
                )
                cur.execute("DELETE FROM Account WHERE ID=?", (acc_id.get(),))
                con.commit()
                con.close()

                log_action(self.current_admin, "UPGRADE_TO_ADMIN", "Account",
                           int(acc_id.get()), f"Username: {data[2]}")

                show_accounts()
                show_admins()
                clear_account()
                messagebox.showinfo("تم", "تمت الترقية إلى Admin بنجاح.")
            except Exception as ex:
                messagebox.showerror("خطأ", str(ex))

        # -------- Account UI --------
        CTkLabel(head_frame, text='ID', width=50, height=25,
                 text_color='gray', font=('arial', 14, 'bold'),
                 fg_color='#F6F5F5', bg_color='#F6F5F5').place(x=80, y=300)
        CTkEntry(head_frame, textvariable=acc_id, justify='center',
                 width=50, height=35, font=('arial', 14, 'bold'),
                 border_color='gray', border_width=1,
                 bg_color='#F6F5F5', fg_color='#F6F5F5',
                 state='readonly').place(x=200, y=300)   # ID للقراءة فقط

        for lbl_text, var, y in [
            ('Account Name',     acc_name,     340),
            ('Account Username', acc_username, 410),
        ]:
            CTkLabel(head_frame, text=lbl_text, width=200, height=25,
                     text_color='gray', font=('arial', 14, 'bold'),
                     fg_color='#F6F5F5', bg_color='#F6F5F5').place(x=20, y=y)
            CTkEntry(head_frame, textvariable=var, justify='center',
                     width=230, height=35, font=('arial', 14, 'bold'),
                     border_color='gray', border_width=1,
                     bg_color='#F6F5F5', fg_color='#F6F5F5').place(x=20, y=y+30)

        CTkLabel(head_frame, text='New Password (optional)', width=200, height=25,
                 text_color='gray', font=('arial', 14, 'bold'),
                 fg_color='#F6F5F5', bg_color='#F6F5F5').place(x=20, y=480)
        en_acc_pass = CTkEntry(head_frame, justify='center', show='*',
                               width=230, height=35, font=('arial', 14, 'bold'),
                               border_color='gray', border_width=1,
                               bg_color='#F6F5F5', fg_color='#F6F5F5')
        en_acc_pass.place(x=20, y=510)

        CTkButton(head_frame, text='Clear', width=100, height=40,
                  fg_color='#DA7297', text_color='white', bg_color='white',
                  font=('arial', 16, 'bold'), hover_color='#DA7297',
                  border_color='#DA7297', corner_radius=5,
                  command=clear_account).place(x=20, y=560)

        CTkButton(head_frame, text='Delete', width=100, height=40,
                  fg_color='#DA7297', text_color='white', bg_color='white',
                  font=('arial', 16, 'bold'), hover_color='#DA7297',
                  border_color='#DA7297', corner_radius=5,
                  command=delete_account).place(x=150, y=560)

        CTkButton(head_frame, text='Upgrade → Admin', width=140, height=40,
                  fg_color='#DA7297', text_color='white', bg_color='white',
                  font=('arial', 13, 'bold'), hover_color='#DA7297',
                  border_color='#DA7297', corner_radius=5,
                  command=upgrade_to_admin).place(x=20, y=610)

        # ================================================================
        #  ACCOUNT TREEVIEW
        # ================================================================
        new_account_tree_f = Frame(head_frame, bg='gray')
        new_account_tree_f.place(x=280, y=330, width=420, height=250)

        style = ttk.Style()
        style.theme_use('clam')
        style.configure('Treeview', bg='#D3D3D3', font=('arial', 12),
                        fg='black', rowheight=30, fieldbackground='white')
        style.configure('Treeview.Heading', background='#DA7297',
                        foreground='white', font=('arial', 12, 'bold'))

        sc1 = Scrollbar(new_account_tree_f)
        sc1.pack(side=RIGHT, fill=Y)

        new_account_tree = ttk.Treeview(
            new_account_tree_f,
            columns=("ID", "name", "username", "password"),
            show='headings',
            yscrollcommand=sc1.set
        )
        sc1.config(command=new_account_tree.yview)

        for col, heading, width in [
            ("ID",       "ID",       40),
            ("name",     "Name",    100),
            ("username", "Username",120),
            ("password", "Password", 90),
        ]:
            new_account_tree.heading(col, text=heading, anchor='center')
            new_account_tree.column(col, width=width, anchor=W)

        new_account_tree.tag_configure('oddrow',  background='lightgray')
        new_account_tree.tag_configure('evenrow', background='#F6F5F5')
        new_account_tree.pack(fill=BOTH, expand=1)
        new_account_tree.bind("<ButtonRelease-1>", get_account_data)
        show_accounts()

        # ================================================================
        #  ADMIN SECTION (الأعمدة اليمين)
        # ================================================================
        var_id_admin       = StringVar()
        var_name_admin     = StringVar()
        var_username_admin = StringVar()

        # -------- Admin CRUD --------
        def show_admins():
            con = get_connection()
            cur = con.cursor()
            try:
                cur.execute("SELECT admin_ID, admin_name, admin_username FROM Admin")
                rows = cur.fetchall()
                admin_tree.delete(*admin_tree.get_children())
                for i, row in enumerate(rows):
                    tag = 'evenrow' if i % 2 == 0 else 'oddrow'
                    admin_tree.insert('', END,
                        values=(row[0], row[1], row[2], '••••••••'), tags=(tag,))
            except Exception as ex:
                messagebox.showerror('خطأ', str(ex))
            finally:
                con.close()

        def get_admin_data(ev):
            item = admin_tree.focus()
            row  = admin_tree.item(item)['values']
            if row:
                var_id_admin.set(row[0])
                var_name_admin.set(row[1])
                var_username_admin.set(row[2])

        def clear_admin():
            for v in (var_id_admin, var_name_admin, var_username_admin):
                v.set("")
            en_admin_pass.delete(0, END)

        def add_admin():
            n  = var_name_admin.get().strip()
            u  = var_username_admin.get().strip()
            p  = en_admin_pass.get()

            if not n or not u or not p:
                messagebox.showerror("خطأ", "أدخل الاسم والـ username وكلمة المرور.")
                return
            if len(p) < 6:
                messagebox.showerror("خطأ", "كلمة المرور أقل من 6 أحرف.")
                return
            try:
                con = get_connection()
                cur = con.cursor()
                cur.execute(
                    "INSERT INTO Admin(admin_name, admin_username, admin_password) VALUES(?,?,?)",
                    (n, u, hash_password(p))      # ← تشفير
                )
                new_id = cur.lastrowid
                con.commit(); con.close()

                log_action(self.current_admin, "ADD_ADMIN", "Admin",
                           new_id, f"Username: {u}")
                show_admins(); clear_admin()
                messagebox.showinfo("تم", "تم إضافة الأدمن بنجاح.")
            except sqlite3.IntegrityError:
                messagebox.showerror("خطأ", "هذا الـ username موجود بالفعل.")
            except Exception as ex:
                messagebox.showerror("خطأ", str(ex))

        def update_admin():
            if not var_id_admin.get():
                messagebox.showerror("خطأ", "اختار أدمن من الجدول أولاً.")
                return
            n = var_name_admin.get().strip()
            u = var_username_admin.get().strip()
            p = en_admin_pass.get()

            if not n or not u:
                messagebox.showerror("خطأ", "الاسم والـ username مطلوبان.")
                return
            try:
                con = get_connection()
                cur = con.cursor()
                if p:
                    # لو كتب باسورد جديدة — نحدّثها مشفّرة
                    if len(p) < 6:
                        messagebox.showerror("خطأ", "كلمة المرور أقل من 6 أحرف.")
                        con.close(); return
                    cur.execute(
                        "UPDATE Admin SET admin_name=?, admin_username=?, admin_password=? "
                        "WHERE admin_ID=?",
                        (n, u, hash_password(p), var_id_admin.get())
                    )
                else:
                    # لو سبها فاضية — نحدّث الاسم والـ username بس
                    cur.execute(
                        "UPDATE Admin SET admin_name=?, admin_username=? WHERE admin_ID=?",
                        (n, u, var_id_admin.get())
                    )
                con.commit(); con.close()

                log_action(self.current_admin, "UPDATE_ADMIN", "Admin",
                           int(var_id_admin.get()), f"Username: {u}")
                show_admins(); clear_admin()
                messagebox.showinfo("تم", "تم تعديل بيانات الأدمن.")
            except sqlite3.IntegrityError:
                messagebox.showerror("خطأ", "هذا الـ username موجود لأدمن آخر.")
            except Exception as ex:
                messagebox.showerror("خطأ", str(ex))

        def delete_admin():
            if not var_id_admin.get():
                messagebox.showerror("خطأ", "اختار أدمن من الجدول أولاً.")
                return
            # منع حذف الأدمن الوحيد
            con = get_connection()
            cur = con.cursor()
            cur.execute("SELECT COUNT(*) FROM Admin")
            count = cur.fetchone()[0]
            con.close()
            if count <= 1:
                messagebox.showerror("خطأ", "لا يمكن حذف الأدمن الأخير في النظام.")
                return

            if not messagebox.askyesno("تأكيد",
                    f"هتحذف الأدمن: {var_username_admin.get()}\nمتأكد؟"):
                return
            try:
                con = get_connection()
                cur = con.cursor()
                cur.execute("DELETE FROM Admin WHERE admin_ID=?", (var_id_admin.get(),))
                con.commit(); con.close()
                log_action(self.current_admin, "DELETE_ADMIN", "Admin",
                           int(var_id_admin.get()), f"Username: {var_username_admin.get()}")
                show_admins(); clear_admin()
                messagebox.showinfo("تم", "تم حذف الأدمن.")
            except Exception as ex:
                messagebox.showerror("خطأ", str(ex))

        # -------- Admin UI --------
        CTkLabel(head_frame, text='ID', width=50, height=25,
                 text_color='gray', font=('arial', 14, 'bold'),
                 fg_color='#F6F5F5', bg_color='#F6F5F5').place(x=790, y=50)
        CTkEntry(head_frame, textvariable=var_id_admin, justify='center',
                 width=50, height=35, font=('arial', 14, 'bold'),
                 border_color='gray', border_width=1,
                 bg_color='#F6F5F5', fg_color='#F6F5F5',
                 state='readonly').place(x=910, y=50)

        for lbl_text, var, y in [
            ('Admin Name',     var_name_admin,     90),
            ('Admin Username', var_username_admin, 160),
        ]:
            CTkLabel(head_frame, text=lbl_text, width=200, height=25,
                     text_color='gray', font=('arial', 14, 'bold'),
                     fg_color='#F6F5F5', bg_color='#F6F5F5').place(x=750, y=y)
            CTkEntry(head_frame, textvariable=var, justify='center',
                     width=230, height=35, font=('arial', 14, 'bold'),
                     border_color='gray', border_width=1,
                     bg_color='#F6F5F5', fg_color='#F6F5F5').place(x=730, y=y+30)

        CTkLabel(head_frame, text='Password', width=200, height=25,
                 text_color='gray', font=('arial', 14, 'bold'),
                 fg_color='#F6F5F5', bg_color='#F6F5F5').place(x=750, y=240)
        en_admin_pass = CTkEntry(head_frame, justify='center', show='*',
                                 width=230, height=35, font=('arial', 14, 'bold'),
                                 border_color='gray', border_width=1,
                                 bg_color='#F6F5F5', fg_color='#F6F5F5')
        en_admin_pass.place(x=730, y=270)

        for text, cmd, y in [
            ('Add',    add_admin,    50),
            ('Clear',  clear_admin, 100),
            ('Update', update_admin,150),
            ('Delete', delete_admin,200),
        ]:
            CTkButton(head_frame, text=text, width=100, height=40,
                      fg_color='#DA7297', text_color='white', bg_color='white',
                      font=('arial', 16, 'bold'), hover_color='#DA7297',
                      border_color='#DA7297', corner_radius=5,
                      command=cmd).place(x=1020, y=y)

        # ================================================================
        #  ADMIN TREEVIEW
        # ================================================================
        admin_tree_f = Frame(head_frame, bg='gray')
        admin_tree_f.place(x=730, y=330, width=420, height=250)

        sc2 = Scrollbar(admin_tree_f)
        sc2.pack(side=RIGHT, fill=Y)

        admin_tree = ttk.Treeview(
            admin_tree_f,
            columns=("admin_ID", "admin_name", "admin_username", "admin_password"),
            show='headings',
            yscrollcommand=sc2.set
        )
        sc2.config(command=admin_tree.yview)

        for col, heading, width in [
            ("admin_ID",       "ID",       40),
            ("admin_name",     "Name",    110),
            ("admin_username", "Username", 90),
            ("admin_password", "Password", 80),
        ]:
            admin_tree.heading(col, text=heading, anchor='center')
            admin_tree.column(col, width=width, anchor=W)

        admin_tree.tag_configure('oddrow',  background='lightgray')
        admin_tree.tag_configure('evenrow', background='#F6F5F5')
        admin_tree.pack(fill=BOTH, expand=1)
        admin_tree.bind("<ButtonRelease-1>", get_admin_data)
        show_admins()

        # ================================================================
        #  ACTIVITY LOG — جدول سجل العمليات (جديد)
        # ================================================================
        CTkLabel(head_frame, text='Activity Log', text_color='#DA7297',
                 font=('arial', 14, 'bold'),
                 fg_color='#F6F5F5', bg_color='#F6F5F5').place(x=280, y=595)

        log_frame = Frame(head_frame, bg='gray')
        log_frame.place(x=280, y=618, width=420, height=0)   # مخفي — يظهر بالزر

        show_log_visible = [False]
        log_tree = None

        def toggle_log():
            if not show_log_visible[0]:
                log_frame.place(x=280, y=618, width=420, height=55)
                _build_log_tree()
                show_log_visible[0] = True
                toggle_log_btn.configure(text='▲ إخفاء السجل')
            else:
                log_frame.place(x=280, y=618, width=420, height=0)
                show_log_visible[0] = False
                toggle_log_btn.configure(text='▼ عرض سجل العمليات')

        def _build_log_tree():
            for w in log_frame.winfo_children():
                w.destroy()
            sc3 = Scrollbar(log_frame); sc3.pack(side=RIGHT, fill=Y)
            lt = ttk.Treeview(log_frame,
                              columns=("time","admin","action","details"),
                              show='headings', yscrollcommand=sc3.set)
            sc3.config(command=lt.yview)
            for col, heading, width in [
                ("time",   "Time",   130),
                ("admin",  "Admin",   70),
                ("action", "Action",  90),
                ("details","Details",100),
            ]:
                lt.heading(col, text=heading, anchor='center')
                lt.column(col, width=width)
            lt.pack(fill=BOTH, expand=1)
            try:
                con = get_connection()
                cur = con.cursor()
                cur.execute(
                    "SELECT log_time, admin_username, action, details "
                    "FROM activity_log ORDER BY log_id DESC LIMIT 50"
                )
                for row in cur.fetchall():
                    lt.insert('', END, values=row)
                con.close()
            except Exception:
                pass

        toggle_log_btn = CTkButton(head_frame, text='▼ عرض سجل العمليات',
                                   width=200, height=28,
                                   fg_color='#DA7297', text_color='white',
                                   font=('arial', 12, 'bold'),
                                   command=toggle_log)
        toggle_log_btn.place(x=280, y=625)


if __name__ == "__main__":
    root = Tk()
    AdminClass(root)
    root.mainloop()
